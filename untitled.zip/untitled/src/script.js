const quizzes = {
  1: [
    { q: "Столиця України?", a: ["Львів", "Київ", "Одеса"], correct: 1 },
    { q: "Яка тварина символізує Україну?", a: ["Вовк", "Лев", "Козак"], correct: 2 },
    { q: "Національна страва України?", a: ["Борщ", "Піцца", "Суші"], correct: 0 }
  ],
  2: [
    { q: "2 + 2 = ?", a: ["3", "4", "5"], correct: 1 },
    { q: "5 * 3 = ?", a: ["15", "10", "20"], correct: 0 },
    { q: "10 - 7 = ?", a: ["3", "2", "4"], correct: 0 }
  ]
};

let currentQuiz = [];
let currentIndex = 0;
let score = 0;

function startQuiz(num) {
  currentQuiz = quizzes[num];
  currentIndex = 0;
  score = 0;
  document.getElementById("menu").style.display = "none";
  document.getElementById("quiz").style.display = "block";
  document.getElementById("result").style.display = "none";
  
  // Змінюємо фон залежно від вікторини
  document.body.style.background = num === 1 ? 
    "linear-gradient(120deg, #ff9a9e, #fad0c4)" : 
    "linear-gradient(120deg, #a1c4fd, #c2e9fb)";
  
  showQuestion();
}

function showQuestion() {
  const q = currentQuiz[currentIndex];
  document.getElementById("question").innerText = q.q;
  const answersDiv = document.getElementById("answers");
  answersDiv.innerHTML = "";

  q.a.forEach((ans, i) => {
    const btn = document.createElement("button");
    btn.innerText = ans;
    btn.onclick = () => checkAnswer(i, btn);
    answersDiv.appendChild(btn);
  });

  document.getElementById("nextBtn").style.display = "none";
}

function checkAnswer(selected, btn) {
  const q = currentQuiz[currentIndex];
  if (selected === q.correct) {
    score++;
    btn.classList.add("correct");
  } else {
    btn.classList.add("wrong");
    const buttons = document.querySelectorAll("#answers button");
    buttons[q.correct].classList.add("correct");
  }

  document.querySelectorAll("#answers button").forEach(b => b.disabled = true);
  document.getElementById("nextBtn").style.display = "inline-block";
}

function nextQuestion() {
  currentIndex++;
  if (currentIndex < currentQuiz.length) {
    showQuestion();
  } else {
    document.getElementById("quiz").style.display = "none";
    document.getElementById("score").innerText = score;
    document.getElementById("result").style.display = "block";
  }
}

function restart() {
  document.getElementById("menu").style.display = "block";
  document.body.style.background = "linear-gradient(120deg, #89f7fe, #66a6ff)";
}